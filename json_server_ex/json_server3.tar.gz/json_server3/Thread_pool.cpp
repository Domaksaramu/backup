#pragma once
#include "Thread_pool.h"
#include "Module_controller.h"


Thread_pool(Json::Value& stored_data, Module_controller *m_controller){
	this->stored_data = stored_data;
	this->m_controller = m_controller;
	t_lock = PTHREAD_MUTEX_INITIALIZER;
	t_cond = PTHREAD_COND_INITIALIZER;
}

void init_Threads(){
	for(int i=0;i<THREAD_NUM;i++){
		pthread_create(&t_ids[i],NULL,&Thread_pool::thread_handler,(void*)this);
	}
}

bool load_request(){
	pthread_mutex_loc(&t_lock);
	while(request_queue.empty())
		pthread_cond_wait(&t_cond, &t_lock);
	Json::Value request = reauest_queue.front();
	reauest_queue.pop();

	//request 처리

	pthread_mutex_unlock(&t_lock);
	return true;
}
void assign_request(Json::Value message){
	pthread_mutex_lock(&t_lock);
	request_queue.push(message);
	pthread_mutex_unlock(&t_lock);
	pthread_cont_signal(&t_cond);
}
static void *thread_handler(void* pArg)
virtual ~thread_pool(){};



