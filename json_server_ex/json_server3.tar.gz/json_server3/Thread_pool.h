#include "json/json.h"
#include <semaphore.h>
#define THREAD_NUM 10

class Module_controller;

class Thread_pool
{
	public:
		Thread_pool(Json::Value& stored_data, Module_controller *m_controller);
		bool load_request();
		void assign_request(Json::Value message);
		static void *thread_handler(void* pArg);
		void init_Threads();
		virtual ~thread_pool(){};
		

		sem_t t_sem;

		Json::Value stored_data;
		queue<Json::Value> request_queue;
		Module_controller *m_controller;
		pthread_t t_ids[THREAD_NUM];
		static pthrddead_mutex_t q_lock;
		static pthread_cont_t q_cond;
};
