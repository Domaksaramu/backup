#include "Stored_data_management.h"

//나중에 구현



